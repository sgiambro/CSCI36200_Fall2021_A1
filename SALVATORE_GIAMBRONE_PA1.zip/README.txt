To run this program you first have to compile the code by entering "make" into the command line. 
Then to run the code type "make run" into the command line as well.
once the code is running all you have to do is enter the desired number of queens you want on the board.